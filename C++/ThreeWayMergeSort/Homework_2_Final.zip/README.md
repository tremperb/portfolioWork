# Analysis of Algorithms Homework
 Homework Assignment 2

# Merge Sort 3

This programs was created and compile with c++ and are called Mergesort3.cpp.
In order to compile these, download the files and connect to the oregon state flip server in your terminal.
With this navigate to the corresponding folder to compile these.
Use:

g++ Mergesort3.cpp
a.out
To compile this sorting algorithm

Each of these print the output to the terminal and a text file
The text file will be "merge3.txt"
These text files are already created in the zip from when I ran it but if you delete them and run the program it will create a new one.


# merge3Time.cpp

These programs are also created with c++ and compile similarily on the flip server but require the c++11 library to include the chrono library
the chrono library tracks the run time for various n.

**MUST COMPILE LIKE THIS:

g++ merge3Time.cpp -std=c++11
a.out

No data is sent to text and is instead printed in terminal as per instructions.

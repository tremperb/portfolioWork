# Analysis of Algorithms Homework
 Homework Assignment 1 

# Merge Sort & Insertion Sort

These programs were created and compile with c++ and are called insertsort.cpp and mergesort.cpp. 
In order to compile these, download the files and connect to the oregon state flip server in your terminal.
With this navigate to the corresponding folder to compile these.
Use: 
g++ insertsort.cpp
a.out
To view that sorting algorithm 
and 
g++ mergesort.cpp
a.out
To view the other

Each of these print the output to the terminal and a text file 
The text files will be "insert.txt" & "merge.txt"
These text files are already created in the zip from when I ran it but if you delete them and run the program it will create a new one.


# insertTime.cpp & mergeTime.cpp

These programs are also created with c++ and compile similarily on the flip server but require the c++11 library to include the chrono library
the chrono library tracks the run time for various n.

MUST COMPILE LIKE THIS
g++ insertTime.cpp -std=c++11
a.out

&

g++ mergeTime.cpp -std=c++11
a.out

No data is sent to text and is instead printed in terminal as per instructions.

